package com.mygdx.game.Sprites;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.physics.box2d.*;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.utils.Array;
import com.mygdx.game.main;
import com.mygdx.game.Screens.PlayScreen;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

public class Mario extends Sprite {
    public Body getB2body() {
        return b2body;
    }

    public enum State{FALLİNG,JUMPİNG,STANDİNG,RUNNİNG};
    public State currentState;
    public State previousState;

    private Animation marioRun;
    private Animation marioJump;
    private float sateTimer;
    private boolean runningRight;

    public World world;
    public Body b2body;
    private TextureRegion marioStand;
    public Mario(World world,PlayScreen screen){
super(screen.getAtlas().findRegion("pixil-frame-0"));

        this.world = world;
        currentState = State.STANDİNG;
        previousState = State.STANDİNG;
        sateTimer = 0;
        runningRight = true;

        Array<TextureRegion> frames = new Array<TextureRegion>();
        for (int i = 1; i <6;i++)
            frames.add(new TextureRegion(getTexture(),i * 18,2,18,18));
        marioRun = new Animation(0.1f,frames);
        frames.clear();
        for(int i = 4; i <6;i++)
            frames.add(new TextureRegion(getTexture(),i * 18,2,16,16));
        marioJump = new Animation(0.1f,frames);
        defineMario();
        marioStand = new TextureRegion(getTexture(),74,2,16,16 );
        setBounds(0,0,16 / main.PPM,16/main.PPM);
        setRegion(marioStand);
    }
    public void update(float dt){

        setPosition(b2body.getPosition().x - getWidth()/2, b2body.getPosition().y-getHeight()/2);
        setRegion(getFrame(dt));

    }

    public TextureRegion getFrame(float dt) {
        currentState = getState();
        TextureRegion region;
        switch (currentState) {
            case JUMPİNG:
                region = (TextureRegion) marioJump.getKeyFrame(sateTimer);
                break;
            case RUNNİNG:
                region = (TextureRegion) marioRun.getKeyFrame(sateTimer,true);
                break;
            case FALLİNG:
            case STANDİNG:

            default:
                region = marioStand;
                break;
        }
        if((b2body.getLinearVelocity().x<0 || !runningRight) && !region.isFlipX()){
            region.flip(true,false);
            runningRight = false;
        }
        else if ((b2body.getLinearVelocity().x>0||runningRight) && region.isFlipX()){
            region.flip(true,false);
            runningRight = true;
        }
        sateTimer = currentState == previousState ? sateTimer + dt : 0;
        previousState = currentState;
        return region;
    }

    public State getState(){
        if(b2body.getLinearVelocity().y>2 || b2body.getLinearVelocity().y<2 && previousState == State.JUMPİNG)
            return State.JUMPİNG;
      else if(b2body.getLinearVelocity().y<0)
            return State.FALLİNG;
      else if (b2body.getLinearVelocity().x != 0)
          return State.RUNNİNG;
      else
          return State.STANDİNG;

    }




    public void  defineMario(){
        BodyDef bdef = new BodyDef();
        bdef.position.set(120 / main.PPM,50/ main.PPM);
        bdef.type = BodyDef.BodyType.DynamicBody;
        b2body = world.createBody(bdef);

        FixtureDef fdef = new FixtureDef();
        CircleShape shape = new CircleShape();
        //5/ main.PPM
        shape.setRadius(5f/ main.PPM);

        fdef.shape = shape;
        b2body.createFixture(fdef);
    }
}

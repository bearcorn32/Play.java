package com.mygdx.game;


import com.badlogic.gdx.Game;
import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.mygdx.game.Screens.PlayScreen;


public class main extends Game {
	public static final int V_WİDTH = 100;
	public static final int V_HEİGHT = 500;
	public static final float PPM = 100;
	public SpriteBatch batch;
public static AssetManager manager;

	@Override
	public void create() {
		batch = new SpriteBatch();
		manager = new AssetManager();
		manager.load("audio/music/Grup-Vitamin-Ahmet.ogg", Music.class);

		manager.finishLoading();
		setScreen(new PlayScreen(this));
	}

	@Override
	public void render() {

		super.render();





	}
}

package com.mygdx.game.Screens;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.maps.MapObject;
import com.badlogic.gdx.maps.objects.RectangleMapObject;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;
import com.badlogic.gdx.utils.viewport.*;
import com.mygdx.game.Sprites.Mario;
import com.mygdx.game.main;

import javax.net.ssl.ExtendedSSLSession;


public class PlayScreen implements Screen {

    private main game;
    Texture texture;
    private OrthographicCamera gamecam;
    private Viewport gameport;
    private TmxMapLoader mapLoader;
    private TiledMap map;
    private OrthogonalTiledMapRenderer renderer;
    private World world;
    private Box2DDebugRenderer b2dr;
    private Mario player;
    private TextureAtlas atlas;
    private boolean debug = false;
    private boolean canJump;

    private int jumpCounter;
    private Music music;



    public PlayScreen(main game) {
        atlas = new TextureAtlas("mario.atlas");
        this.game = game;
        this.jumpCounter = 0;
        gamecam = new OrthographicCamera();
        gameport = new ExtendViewport(main.V_WİDTH / 100, main.V_HEİGHT/main.PPM , gamecam);

        mapLoader = new TmxMapLoader();
        map = mapLoader.load("adsız.tmx");
        renderer = new OrthogonalTiledMapRenderer(map,1/ main.PPM);
        gamecam.position.set(gameport.getScreenWidth() / main.PPM, gameport.getScreenHeight() / 50, 0);


        world = new World(new Vector2(0, -10 / main.PPM), true);
        b2dr = new Box2DDebugRenderer();
        player = new Mario(world,this);

        BodyDef bdef = new BodyDef();
        PolygonShape shape = new PolygonShape();
        FixtureDef fdef = new FixtureDef();
        Body body;

        //foot sensor

        shape.setAsBox(100/main.PPM,100/main.PPM,new Vector2(player.b2body.getPosition().x  ,player.b2body.getPosition().y ),0);
        fdef.shape = shape;


music = main.manager.get("audio/music/Grup-Vitamin-Ahmet.ogg", Music.class);

music.setLooping(true);
music.play();

        //create ground bodies/fixtures
        for (MapObject object : map.getLayers().get(5).getObjects().getByType(RectangleMapObject.class)) {

            Rectangle rect = ((RectangleMapObject) object).getRectangle();

            bdef.type = BodyDef.BodyType.StaticBody;
            bdef.position.set((rect.getX() + rect.getWidth() / 2) / main.PPM, (rect.getY() + rect.getHeight() / 2) / main.PPM);

            body = world.createBody(bdef);

            shape.setAsBox(rect.getWidth() / 2 / main.PPM, rect.getHeight() / 2 / main.PPM);
            fdef.shape = shape;
            body.createFixture(fdef);

        }


    }

    public TextureAtlas getAtlas() {
        return atlas;
    }

    @Override
    public void show() {

    }


    public void handleInput(float dt) {



        if (Gdx.input.isKeyJustPressed(Input.Keys.W)|| Gdx.input.isKeyJustPressed(Input.Keys.SPACE) && player.previousState != Mario.State.JUMPİNG && player.b2body.getLinearVelocity().y<2) {

            if(player.previousState == Mario.State.JUMPİNG){player.b2body.applyLinearImpulse(new Vector2(0, 0.3f), player.b2body.getWorldCenter(), false);}
                player.b2body.applyLinearImpulse(new Vector2(0, 0.3f), player.b2body.getWorldCenter(), true);


        }


        if (Gdx.input.isKeyPressed(Input.Keys.D) && player.b2body.getLinearVelocity().x <= 0.1)
            player.b2body.applyLinearImpulse(new Vector2(0.1f, 0), player.b2body.getWorldCenter(), true);
        if (Gdx.input.isKeyPressed(Input.Keys.A) && player.b2body.getLinearVelocity().x >= -0.1)
            player.b2body.applyLinearImpulse(new Vector2(-0.1f, 0), player.b2body.getWorldCenter(), true);


    }

    public void update(float dt) {
        handleInput(dt);
        player.update(dt);
        world.step(1 / 10f, 6, 2);
        gamecam.position.x = player.b2body.getPosition().x;
        gamecam.update();
        renderer.setView(gamecam);
    }


    @Override
    public void render(float delta) {
        update(delta);
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        //renderer game map
        renderer.render();
        //rendere box2ddebuglines
        if(debug) {
            b2dr.render(world, gamecam.combined);
        }
        //set
        game.batch.setProjectionMatrix(gamecam.combined);
        game.batch.begin();
        player.draw(game.batch);
        game.batch.end();


    }

    @Override
    public void resize(int width, int height) {
        gameport.update(width, height);
    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        map.dispose();
        renderer.dispose();
        b2dr.dispose();
        world.dispose();


    }
}

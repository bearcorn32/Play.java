<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="magarajam" tilewidth="16" tileheight="16" tilecount="42" columns="7">
 <image source="pixil-frame-0 (6).png" width="112" height="96"/>
</tileset>

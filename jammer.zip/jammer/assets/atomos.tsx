<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="atomos" tilewidth="16" tileheight="16" tilecount="1125" columns="45">
 <image source="atomos.png" width="723" height="402"/>
</tileset>

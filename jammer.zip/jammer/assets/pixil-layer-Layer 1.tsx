<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="pixil-layer-Layer 1" tilewidth="16" tileheight="16" tilecount="200" columns="20">
 <image source="pixil-layer-Layer 1.png" width="320" height="160"/>
</tileset>

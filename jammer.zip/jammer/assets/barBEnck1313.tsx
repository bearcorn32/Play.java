<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="barBEnck1313" tilewidth="16" tileheight="16" tilecount="441" columns="21">
 <image source="barBEnck1313.jpg" width="350" height="350"/>
</tileset>

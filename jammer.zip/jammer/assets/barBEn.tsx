<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="barBEn" tilewidth="16" tileheight="16" tilecount="1849" columns="43">
 <image source="barBEn.jpg" width="700" height="700"/>
</tileset>

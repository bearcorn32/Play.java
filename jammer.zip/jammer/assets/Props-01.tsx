<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Props-01" tilewidth="16" tileheight="16" tilecount="112" columns="8">
 <image source="Props-01.png" width="128" height="224"/>
</tileset>
